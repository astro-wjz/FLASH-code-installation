a=GetDataSDF('../../../Data/wjz1/0001.sdf');
imagesc(a.Electric_Field.Ey.data)
imagesc(a.Derived.Mass_Density.data)
plot(a.Particles.Ek.carbon.grid.x,a.Particles.Ek.carbon.data)
scatter(a.Particles.Ek.carbon.grid.x,a.Particles.Ek.carbon.data,1.2)
